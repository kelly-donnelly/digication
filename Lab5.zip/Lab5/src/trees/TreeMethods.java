package trees;

/**
 * TODO - add some comments!
 *
 * @author TODO - Your name here
 * @author John Donaldson
 * @author Benjamin Kuperman (Spring 2007, 2008)
 */

// TODO: See Part 2

public class TreeMethods {

	public TreeMethods() {
	}

	public int nodeCount(BinaryTree<String> tree) {
		return 0;
	}

	public int height(BinaryTree<String> tree) {
		return -1;
	}

	public int levelCount(BinaryTree<String> tree, int level) {
		return 0;
	}

	public int weightBalanceFactor(BinaryTree<String> tree) {
		return 0;
	}

	public int leafCount(BinaryTree<String> tree) {
		return 0;
	}

	public BinaryTree<String> mirrorImage(BinaryTree<String> tree) {
		return new EmptyTree<String>();
	}

	public int nodeSum(BinaryTree<String> tree) {
		return 0;
	}

	public int maxPathSum(BinaryTree<String> tree) {
		return 0;
	}

	public void doubles(BinaryTree<String> tree) {
	}

	// Traversals
	public String preOrder(BinaryTree<String> tree) {
		// TODO
		return null;
	}

	public String postOrder(BinaryTree<String> tree) {
		// TODO
		return null;
	}

	public String inOrder(BinaryTree<String> tree) {
		// TODO
		return null;
	}
}
