package trees;

public abstract class BinaryTree<T> {
    abstract String toString(String indent);
    abstract boolean isEmpty();
   
}
