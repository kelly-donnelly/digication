package trees;

public class ConsTree<T> extends BinaryTree<T> {
	private T data;
	private BinaryTree<T> leftChild;
	private BinaryTree<T> rightChild;

	public ConsTree(T data, BinaryTree<T> left, BinaryTree<T> right) {
		this.data = data;
		leftChild = left;
		rightChild = right;
	}

	public ConsTree(T data) {
		this(data, new EmptyTree<T>(), new EmptyTree<T>());
	}
	
	public boolean isEmpty() {
		return false;
	}

	public String toString(String indent) {
		if (rightChild.isEmpty() && leftChild.isEmpty())
			return indent + "\n" + indent + data.toString();
		else if (rightChild.isEmpty())
			return "\n" + indent + "\n" + indent + data.toString() + "\n" + indent + "\\"
			+ leftChild.toString(indent + "   ");
		else if (leftChild.isEmpty())
			return rightChild.toString(indent + "   ") + "\n" + indent + "/\n" + indent + data.toString() + "\n"
			+ indent + "\\";
		else
			return rightChild.toString(indent + "   ") + "\n" + indent + "/\n" + indent + data.toString() + "\n"
			+ indent + "\\" + leftChild.toString(indent + "   ");

	}

	public String toString() {
		return toString("");
	}


}
