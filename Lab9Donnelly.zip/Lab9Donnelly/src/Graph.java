/*
 * Kelly Donnelly
 * CSCI 151 Lab 9
*/

package Lab9Donnelly;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class Graph {
	public static int Infinity = Integer.MAX_VALUE;

	private HashMap<String, Vertex> vertexMap;
	private LinkedList<Vertex> actors;
	private LinkedList<Vertex> movies;

	public Graph() {
		vertexMap = new HashMap<String, Vertex>();
		movies = new LinkedList<Vertex>();
		actors = new LinkedList<Vertex>();
	}

	public Vertex getVertex(String name) {
		Vertex v = vertexMap.get(name);
		if (v == null) {
			v = new Vertex(name);
			vertexMap.put(name, v);
		}
		return v;
	}

	HashMap<String, Vertex> vertexMap() {
		return vertexMap;
	}

	public int vertexCount() {
		return vertexMap.size();
	}
	

	public void addEdge(String source, String dest) {
//	System.out.printf("Adding edge from %s to %s\n", source, dest);
		Vertex v = getVertex(source);
		Vertex w = getVertex(dest);
		List<Edge> L = v.adjacents();
		L.add(new Edge(w));
	}
	
	public void printAvailableActors() {
		for (Vertex e : actors) 
			System.out.printf("%d: %s\n", e.distance / 2 , e);
	
	}


	public void printAvailableMovies() {
		for (Vertex e : movies)
			System.out.printf("%s\n", e);
	}


	/*
	 * EVERYTHING ABOVE THIS LINE IS ALREADY IMPLEMENTED
	 */
	
	/*
	 * This reads the named file one line at a time and builds the graph.
	 * The file is formatted in the form
	 *             source|destination
	 */
	public void loadFile(String fName) {
		int counter = 0;
		Scanner scan;
		try {
			if (fName.substring(0, 4).equals("http"))
				scan = new Scanner(new URL(fName).openStream());
			else
				scan = new Scanner(new File(fName));
		
		Graph newGraph = new Graph();
		
		while (scan.hasNextLine()) {
			
			String line = scan.nextLine();
			
			int seperator = line.indexOf( '|');
			
			String act = line.substring(0, seperator);
			String mov = line.substring(seperator+1);
			
			addEdge(act,mov);
			addEdge(mov,act);

			counter += 1;
		}
		} catch (FileNotFoundException e) {
			System.out.printf("File '%s' not found\n", fName);
		} catch (IOException e) {
		}
		
		System.out.printf("Read %d lines from '%s'\n", counter, fName);
	}

	public void refresh() {
		
		movies = new LinkedList<Vertex>();
		actors = new LinkedList<Vertex>();
		Set<String> nodes = vertexMap.keySet();
		Iterator<String> it = nodes.iterator();
		while (it.hasNext()) {
			Vertex v = vertexMap.get(it.next());
			//SET THE PRED AND DISTANCE VALUES OF VERTEX v
			//BACK TO null AND INFINITY
			v.predecessor = null;
			v.distance = Integer.MAX_VALUE;
		}		
	}
	
	
	/*
	 * This implements the All Paths Single Source algorithm. As it processes
	 * the graph, if it finds that a node has a less-than-infinite distance 
	 * from the source node it should add the node to either the available 
	 * movie list or the available actors list.
	 * Note that a node of the graph represents an actor if its distance is
	 * even,and it represents a movie if its distance is odd.
	 */
	public void findAllPaths(String s) {
		
		LinkedList <Vertex> queue = new LinkedList<Vertex>();
		
		Vertex v = vertexMap.get(s);
		actors.add(v);
		
		v.distance = 0;
		v.predecessor = null;
		queue.offer(v);
		

		while (queue.size()>0) {
			Vertex currVer = queue.poll();
			
			for (Edge e : currVer.adjacentList) {
				Vertex D = e.destination;
				
				if (D.distance == Integer.MAX_VALUE) {
					D.distance = currVer.distance +1;
					D.predecessor = currVer;
					queue.offer(D);
					
						if (D.distance % 2 == 0) {
							actors.add(D);
						}
						else {
							movies.add(D);
						}
				}
			}
		}
	}
}
