/*
 * Kelly Donnelly
 * CSCI 151 Lab 9
*/

package Lab9Donnelly;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class Vertex {
	String name;
	List<Edge> adjacentList;
	// ADD DISTANCE AND PRED VARIABLES HERE
	int distance;
	Vertex predecessor;
	
	public Vertex(String name) {
		this.name = name;
		adjacentList = new LinkedList<Edge>();
		// INITIALIZE DISTANCE AND PRED VARIABLES HERE
		this.distance = Integer.MAX_VALUE;
		this.predecessor = null; 
	}
	
	public int distance() {
		
		int dist;
		
		for (dist = 0; dist <= adjacentList.indexOf(predecessor); dist++) {};
		distance = dist;
		
		// ACTUALLY RETURN THE DISTANCE VARIABLE
		return distance;
	}

	public List<Edge> adjacents() {
		return adjacentList;
	}

	public String toString() {
		return name;
	}

    /*
     * This is called, after the allPaths algorithm is run, to represent the
     * path from the source to this vertex.
     * Follow the predecessor nodes back to the source (whose predecessor should
     * be null), each time pushing the vertex
     * onto a stack. Then pop the stack until it is empty, each time adding a
     * String version of the vertex onto a String.
     * When the stack is empty return the string.
     * If 'A">is the source e, "C" is the current node and the path goes
     * through "B" this should return something like
     * "A => B => C"
     */
	
	private HashMap<String, Vertex> vertexMap = new HashMap<String, Vertex>();
	
	public Vertex getVertex(String name) {
		
		Vertex v = vertexMap.get(name);
		
		if (v == null) {
			v = new Vertex(name);
			vertexMap.put(name, v);
		}
		
		return v;
	}
	
	public String getPath() {


		Stack newStack = new Stack <String>();
		Vertex nameVer = getVertex(name);

		while (predecessor != null ) {
			
			newStack.push(nameVer);

			nameVer = predecessor;
			predecessor = nameVer.predecessor;
			
		}

		String s = "";
		int ogSize = newStack.size();
		
		
		while (!newStack.isEmpty()) {

			if (newStack.size() == ogSize) {
				s = s +newStack.pop() + " " ;
			}
			else if(newStack.size() > 1 && newStack.size() < ogSize) {
				s = s+ " => "+newStack.pop();
			}
			
			else if (newStack.size() == 1) {
				s = s+  " => " +newStack.pop();
			}
			
		}
		
		s = nameVer +  " => "+  s;
		
		return s;
	}
}



