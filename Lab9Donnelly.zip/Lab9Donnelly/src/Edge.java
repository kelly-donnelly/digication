/*
 * Kelly Donnelly
 * CSCI 151 Lab 9
*/
package Lab9Donnelly;

public class Edge {
	
	public Vertex destination;
	

	public Edge(Vertex d) {
		destination = d;
	}

	public Vertex destination() {
		return destination;
	}
}
